package com.example.bookstoreapp.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class BookRepository {
    private BookDao mBookDao;
    private LiveData<List<Book>> mAllBooks;

    BookRepository(Application application) {
        LibDatabase db = LibDatabase.getDatabase(application);
        mBookDao = db.bookDao();
        mAllBooks = mBookDao.getAllBook();
    }

    LiveData<List<Book>> getAllBooks() {
        return mAllBooks;
    }

    void insert(Book book) {
        LibDatabase.databaseWriteExecutor.execute(() -> mBookDao.addBook(book));
    }

    void deleteLastBook() {
        LibDatabase.databaseWriteExecutor.execute(() -> mBookDao.deleteLastBook());
    }

    void deleteBookPriceExceed50() {
        LibDatabase.databaseWriteExecutor.execute(() -> mBookDao.deleteBookPriceExceed50());
    }

    void deleteAll(){
        LibDatabase.databaseWriteExecutor.execute(()->{
            mBookDao.deleteAllBook();
        });
    }


}
