package com.example.bookstoreapp.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface BookDao {
    @Query("select * from books")
    LiveData<List<Book>> getAllBook();

    @Query("select * from books where title=:name")
    List<Book> getBook(String name);

    @Insert
    void addBook(Book book);

    @Query("delete from books where title= :name")
    void deleteBook(String name);

    @Query("delete from books where bookID = (SELECT MAX(bookID) FROM books)")
    void deleteLastBook();

    @Query("delete from books where price > 50")
    void deleteBookPriceExceed50();

    @Query("delete FROM books")
    void deleteAllBook();

}
