package com.example.bookstoreapp;

import static com.example.bookstoreapp.RandomString.generateNewRandomString;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookstoreapp.provider.Book;
import com.example.bookstoreapp.provider.BookViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText bookIDEt;
    EditText titleEt;
    EditText ISBNEt;
    EditText authorEt;
    EditText descriptionEt;
    EditText priceEt;
    DrawerLayout drawerLayout;

    //------------------------------Array and RecyclerView-------------------------------------
//    ArrayList<Book> myList = new ArrayList<>();
//    RecyclerView recyclerView;
//    RecyclerView.LayoutManager layoutManager;
//    MyRecyclerViewAdapter myAdapter;
    //--------------------------------------Database-------------------------------------------
    private BookViewModel mBookViewModel;
    //--------------------------------------Firebase-------------------------------------------
    DatabaseReference myRef;

    //-------------------------------------Touch frame------------------------------------------
    View touchFrame;
    int initial_x;
    int initial_y;

    //-------------------------------------Gesture detector-------------------------------------
    GestureDetector gestureDetector;
    ScaleGestureDetector scaleGestureDetector;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer);

        bookIDEt = findViewById(R.id.editTextBookID);
        titleEt = findViewById(R.id.editTextTitle);
        ISBNEt = findViewById(R.id.editTextISBN);
        authorEt = findViewById(R.id.editTextAuthor);
        descriptionEt = findViewById(R.id.editTextDes);
        priceEt = findViewById(R.id.editTextPrice);

        /* Request permissions to access SMS */
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        /* Create and instantiate the local broadcast receiver
           This class listens to messages come from class SMSReceiver
         */
        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();

        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver
         * */
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER));

        //-------------------------------------Toolbar----------------------------------------------
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ------------------------------------ List view -----------------------------------------
//        ListView listView = findViewById(R.id.listView);
//        // context, layout, data source (array)
//        myAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, myList); //simple_list_item_1 is the layout design we are using for the listview
//        listView.setAdapter(myAdapter);

        // ----------------------------------- Drawer ----------------------------------------------
        drawerLayout =  findViewById(R.id.drawerLayout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(new MyDrawerListener());


        // ---------------------------------Floating Action Button----------------------------------
        // retrieve id of fab button and set onClick function
        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        // Function attach to FAB
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addBook();
            }
        });

//        //----------------------------------------Recycler View---------------------------------------
//        recyclerView = findViewById(R.id.rv);
//
//        layoutManager = new LinearLayoutManager(this);  //A RecyclerView.LayoutManager implementation which provides similar functionality to ListView.
//        recyclerView.setLayoutManager(layoutManager);   // Also StaggeredGridLayoutManager and GridLayoutManager or a custom Layout manager
//
//        // Adapter connect to data
//        myAdapter = new MyRecyclerViewAdapter(); // using own adapter we created (differ from listView)
//        myAdapter.setData(myList);
//        recyclerView.setAdapter(myAdapter);

        //----------------------------------------BookViewModel---------------------------------------
        mBookViewModel = new ViewModelProvider(this).get(BookViewModel.class);

        //----------------------------------------Fragment---------------------------------------------
        getSupportFragmentManager().beginTransaction().replace(R.id.frame1, new ListBooksFragment()).commit();

        //--------------------------------------Firebase database---------------------------------------
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Book/myBook");

        //--------------------------------------- Motion event -------------------------------------------
        touchFrame = findViewById(R.id.touchFrame);

        gestureDetector = new GestureDetector(this, new MyGestureDetector());
//        scaleGestureDetector = new ScaleGestureDetector(this, new MyScaleGestureDetector());


        touchFrame.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                gestureDetector.onTouchEvent(event);
//                scaleGestureDetector.onTouchEvent(event);
                return true;
            }
        });


    }


    // ------------------------------------ Drawer Listener-----------------------------------------------
    class MyDrawerListener implements NavigationView.OnNavigationItemSelectedListener {
        // Function for each menu item (buttons) in drawer
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id for each menu item
            int id = item.getItemId();
//            MainActivity main = new MainActivity();
            if (id == R.id.drawer_option_add) {
                // call addBook function
                addBook();
            } else if (id == R.id.drawer_option_remove_last) {
                mBookViewModel.deleteLastBook();
//                myList.remove(myList.size()-1);
//                myAdapter.notifyDataSetChanged();
            } else if (id == R.id.drawer_option_remove_all) {
                mBookViewModel.deleteAll();
                myRef.removeValue();
//                myList.removeAll(myList);
//                myAdapter.notifyDataSetChanged();
            } else if (id == R.id.drawer_option_close) {
                finish();
            }
            else if (id == R.id.drawer_option_listall) {
                newActivity();
            } else if (id == R.id.drawer_option_deleteBook50) {
                mBookViewModel.deleteBookPriceExceed50();
            }
            // close the drawer
            drawerLayout.closeDrawers();
            // tell the OS
            return true;
        }
    }
    public void newActivity() {
        Intent i = new Intent(this, ListBooksActivity.class);
        startActivity(i);
    }



    //-------------------------------------Option Menu-------------------------------------------
    // Inflate Option menu on toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Function for each menu item in options menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.option_menu_clear) {
            // call clearText() function
            clearText();
        } else if (id == R.id.option_menu_load) {
            // call reloadSaveAttribute() function
            reloadSaveAttributes();
        } else if (id == R.id.option_menu_totalBooks) {
            mBookViewModel.getAllBooks().observe(this, newData -> {
                Toast.makeText(this, "Total Books: " + newData.size(), Toast.LENGTH_SHORT).show();
            });
        }
        // tell the OS
        return true;
    }




    // ---------------------------------------addBook function ----------------------------------------
    public void addBook() {
        String ID = bookIDEt.getText().toString();
        String title = titleEt.getText().toString();
        String author = authorEt.getText().toString();
        String ISBN = ISBNEt.getText().toString();
        String Des = descriptionEt.getText().toString();
        String price = priceEt.getText().toString();

        Toast addBookMessage = Toast.makeText(this, "Book (" + title + ") and the price ("
                + price + ")", Toast.LENGTH_SHORT);

        addBookMessage.show();

        // save data as persistent data into shared preferences
        SharedPreferences mySP = getSharedPreferences("F1",0); // 0 is private mode
        SharedPreferences.Editor myEditor = mySP.edit();

        myEditor.putString("BOOK_ID",bookIDEt.getText().toString());
        myEditor.putString("TITLE", titleEt.getText().toString());
        myEditor.putString("ISBN", ISBNEt.getText().toString());
        myEditor.putString("AUTHOR", authorEt.getText().toString());
        myEditor.putString("DESCRIPTION", descriptionEt.getText().toString());
        myEditor.putFloat("PRICE", Float.parseFloat(priceEt.getText().toString()));
        myEditor.commit();

        // Add book into database
        Book bookObj = new Book(ID,title,author,ISBN,Des,Double.parseDouble(price));
        mBookViewModel.insert(bookObj);
        myRef.push().setValue(bookObj);
    }

    // Clear the fields
    public void clearText() {
        bookIDEt.setText("");
        titleEt.setText("");
        ISBNEt.setText("");
        authorEt.setText("");
        descriptionEt.setText("");
        priceEt.setText("");
    }


    //Button for load saved attributes
    public void reloadSaveAttributes() {
        // retrieve persistent data from shared preferences
        SharedPreferences mySP = getSharedPreferences("F1",0);
        bookIDEt.setText(mySP.getString("BOOK_ID",""));
        titleEt.setText(mySP.getString("TITLE",""));
        ISBNEt.setText(mySP.getString("ISBN",""));
        authorEt.setText(mySP.getString("AUTHOR",""));
        descriptionEt.setText(mySP.getString("DESCRIPTION",""));
        priceEt.setText(String.valueOf(mySP.getFloat("PRICE",0)));
    }

    public void setISBN(View v){
        SharedPreferences mySP = getSharedPreferences("F1",0); // 0 is private mode
        SharedPreferences.Editor myEditor = mySP.edit();
        myEditor.putString("ISBN", "00112233");
        myEditor.commit();
    }

    // Double the price
    public void doublePrice(View v) {
        EditText priceText = findViewById(R.id.editTextPrice);
        double price = Double.parseDouble(priceText.getText().toString());
        double doublePrice = price * 2;
        priceText.setText(Double.toString(doublePrice));
    }

    @Override
    protected void onStart() {
        super.onStart();
        // retrieve persistent data from shared preferences
        SharedPreferences mySP = getSharedPreferences("F1",0);
        bookIDEt.setText(mySP.getString("BOOK_ID",""));
        titleEt.setText(mySP.getString("TITLE",""));
        ISBNEt.setText(mySP.getString("ISBN",""));
        authorEt.setText(mySP.getString("AUTHOR",""));
        descriptionEt.setText(mySP.getString("DESCRIPTION",""));
        priceEt.setText(String.valueOf(mySP.getFloat("PRICE",0)));
        // hence text typed on plaintext will remain even after destroying activity (back button)
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @SuppressLint("MissingSuperCall")
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        //comment out the super - so other field will not be save
//        super.onSaveInstanceState(outState);

        // Save the  title and ISBN into the outState bundle
        outState.putString("TITLE",titleEt.getText().toString());
        outState.putString("ISBN",ISBNEt.getText().toString());
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        //comment out the super - so other field will not be restore
//        super.onRestoreInstanceState(savedInstanceState);

        // Retrieve message from savedInstanceState bundle
        titleEt.setText(savedInstanceState.getString("TITLE"));
        ISBNEt.setText(savedInstanceState.getString("ISBN"));
    }

    // -------------------------------------SMS------------------------------------------
    class MyBroadCastReceiver extends BroadcastReceiver {

        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */
            StringTokenizer sT = new StringTokenizer(msg, "|");
            String bookID = sT.nextToken();
            String title = sT.nextToken();
            String ISBN = sT.nextToken();
            String author = sT.nextToken();
            String description = sT.nextToken();
            String price = sT.nextToken();
            boolean addPrice = Boolean.parseBoolean(sT.nextToken());

            /*
             * Now, its time to update the UI
             * */
            bookIDEt.setText(bookID);
            titleEt.setText(title);
            ISBNEt.setText(ISBN);
            authorEt.setText(author);
            descriptionEt.setText(description);
            if (addPrice == true) {
                priceEt.setText(String.valueOf(Double.parseDouble(price)+100));
            }
            else {
                priceEt.setText(String.valueOf(Double.parseDouble(price)+5));
            }
        }
    }
    class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onSingleTapUp(@NonNull MotionEvent e) {
            Log.i("week11","onSingleTapUp");
            String randomISBN = generateNewRandomString(5);
            ISBNEt.setText(randomISBN);
            return super.onSingleTapUp(e);
        }
        @Override
        public boolean onDoubleTap(@NonNull MotionEvent e) {
            Log.i("week11","onDoubleTap");
            clearText();
            return super.onDoubleTap(e);
        }
        @Override
        public void onLongPress(@NonNull MotionEvent e) {
            Log.i("week11","onLongPress");
            reloadSaveAttributes();
            super.onLongPress(e);
        }

        @Override
        public boolean onScroll(@NonNull MotionEvent e1, @NonNull MotionEvent e2, float distanceX, float distanceY) {
            Log.i("week11","onScroll");
            double price = Double.parseDouble(priceEt.getText().toString());

            if (e2.getX() > e1.getX())
            {
                price += 1;
                priceEt.setText(Double.toString(price));
            }
            else if (e2.getX() < e1.getX())
            {
                price -= 1;
                priceEt.setText(Double.toString(price));

            }
            return super.onScroll(e1, e2, distanceX, distanceY);
        }

        @Override
        public boolean onFling(@NonNull MotionEvent e1, @NonNull MotionEvent e2, float velocityX, float velocityY) {
            if(velocityX>1000 || velocityX<-1000){
                moveTaskToBack(true);
                Log.i("week11","onFling");
            }
            else if (velocityY>1000 || velocityY<-1000){
                titleEt.setText("untitled");
            }
            return super.onFling(e1, e2, velocityX, velocityY);
        }

    }



}




