package com.example.bookstoreapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookstoreapp.provider.Book;

import java.util.ArrayList;
import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder>{
    List<Book> data = new ArrayList<>();

    public void setData(List<Book> data) { //auto pass in declared data as argument
        this.data = data;
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate card view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent, false);
        // attachToRoot false - add child to parentView not now
        // CardView inflated as RecyclerView list item
        // Create new ViewHolder
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;    // return viewHolder will be use in onBindViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapter.ViewHolder holder, int position) {
        // Put data into view component in cardview
        holder.bookID.setText("ID: " + data.get(position).getID()); //holder is basically the returned viewHolder from onCreateViewHolder() func
        holder.bookTitle.setText("Title: " + data.get(position).getTitle());
        holder.bookAuthor.setText("Author: " + data.get(position).getAuthor());
        holder.bookISBN.setText("ISBN: " + data.get(position).getISBN());
        holder.bookDes.setText("DESC: " + data.get(position).getDes());
        holder.bookPrice.setText("Price: " + data.get(position).getPrice().toString());
        holder.bookPos.setText("Position: " + position);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // acts like holder which bind all the view component in card view
        public TextView bookID;
        public TextView bookTitle;
        public TextView bookAuthor;
        public TextView bookISBN;
        public TextView bookDes;
        public TextView bookPrice;
        public TextView bookPos;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bookID = itemView.findViewById(R.id.bookID);
            bookTitle = itemView.findViewById(R.id.bookTitle);
            bookAuthor = itemView.findViewById(R.id.bookAuthor);
            bookISBN = itemView.findViewById(R.id.bookISBN);
            bookDes = itemView.findViewById(R.id.bookDes);
            bookPrice = itemView.findViewById(R.id.bookPrice);
            bookPos = itemView.findViewById(R.id.bookPos);
        }
    }
}
