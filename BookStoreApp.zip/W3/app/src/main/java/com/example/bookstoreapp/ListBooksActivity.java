package com.example.bookstoreapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListBooksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_books);

        getSupportFragmentManager().beginTransaction().replace(R.id.frame2, new ListBooksFragment()).commit();

    }
}